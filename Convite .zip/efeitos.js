// ==========================
// CORAÇÕES SUBINDO ❤️
// ==========================

function criarCoracao(){

    const coracao = document.createElement("div");

    coracao.className = "coracao-subindo";

    coracao.innerHTML = "❤️";

    coracao.style.left = Math.random() * 100 + "vw";

    coracao.style.animationDuration = (3 + Math.random() * 3) + "s";

    document.body.appendChild(coracao);


    setTimeout(()=>{

        coracao.remove();

    },6000);

}


setInterval(criarCoracao,500);



// ==========================
// BOMBA CORAÇÃO 💥❤️
// ==========================

function bombaCoracao(){

    const coracao = document.createElement("div");

    coracao.className = "bomba-coracao";

    coracao.innerHTML = "❤️";


    document.body.appendChild(coracao);


    setTimeout(()=>{

        coracao.innerHTML = "💖";

        coracao.style.fontSize = "150px";


    },1000);



    setTimeout(()=>{

        coracao.remove();

    },2000);

}